using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStatus : Status {
   
    public float timeBetweenRandomPosition = 4f;

}
